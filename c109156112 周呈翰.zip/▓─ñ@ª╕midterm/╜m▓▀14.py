list1 = list(input("輸入一字串為:"))
count_list1 = 0
for i  in list1:
    count_list1 +=1
print("There are",count_list1,"characters")
    
m = int(input("請輸入階乘值 M "))
a = 1
b = 1
while(m >b):
    a=a+1
    b= b*a
print("超過 M 值為",m,"的最小值為",a)

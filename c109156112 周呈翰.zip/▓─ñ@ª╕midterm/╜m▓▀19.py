student = {"123":"TOM DTGD","456":"CAT CSIE","789":"NANA ASIE","321":"LIM DBA","654":"WON FDD"}
ser = input("輸入查詢學號為：")
print(type(ser))
print(student[ser])


s1 = list(input("輸入一句句子"))
s2 = list(input("輸入一句句子"))
if s1<=s2:
    print("YES")
else:
    print("NO")
class University:
    def __init__(self,name):
        self.name =name
        self.cps =[]
class Department:
    def __init__(self,name):
        self.name = name
class Campus:
    def __init__(self,name):
        self.name =name
        self.dep =[]
nkust =University("國立高雄科技大學")
cpsname = ["建工校區","旗津","第一","楠梓","燕巢"]
dpsname= ['智商',"金資","會資","財稅","觀光"]
for i in cpsname:
    nkust.cps.append(Campus(i))
for i in dpsname:
    nkust.cps[4].dep.append(Department(i))





